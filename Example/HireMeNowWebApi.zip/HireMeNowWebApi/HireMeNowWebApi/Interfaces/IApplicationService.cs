﻿namespace HireMeNowWebApi.Interfaces
{
	public interface IApplicationService
	{
		void AddApplication(Guid JobId, Guid UserId);
	}
}
